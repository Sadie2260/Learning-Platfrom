import React from 'react'
import '@fortawesome/fontawesome-free/css/all.min.css';


export default function BlogCard() {
    const categories = [
        { name: 'Web Design', count: 24 },
        { name: 'Marketing', count: 15 },
        { name: 'Frontend', count: 8 },
        { name: 'IT & Software', count: 13 },
        { name: 'Photography', count: 4 },
        { name: 'Technology', count: 16 },
        { name: 'General', count: 12 },
      ];
  return (
    <div>
    <div class="container">
  <div class="row">
    <div class="col-sm-4">
    <div className="post-card">
      <div className="post-image">
        <img src="https://img.freepik.com/premium-psd/discount-3d-podium-product-display-social-media-instagram-story-template-flash-sale-super-sale_125322-160.jpg?uid=R134543391&ga=GA1.1.1753247489.1710237827&semt=ais_hybrid" alt="Post" />
      </div>
      <div className="post-info">
        <div className="post-meta">
          <span><i className="fas fa-calendar-alt"></i> January 24, 2020</span>
          <span><i className="fas fa-comments"></i> 4 Comments</span>
        </div>
        <h3 className="post-title">Insights on How to Improve Your Teaching.</h3>
        <a href="#" className="read-more">Read More <i className="fas fa-arrow-right"></i></a>
      </div>
    </div>
    </div>
    <div class="col-sm-4">
    <div className="post-card">
      <div className="post-image">
        <img src="https://img.freepik.com/premium-psd/discount-3d-podium-product-display-social-media-instagram-story-template-flash-sale-super-sale_125322-160.jpg?uid=R134543391&ga=GA1.1.1753247489.1710237827&semt=ais_hybrid" alt="Post" />
      </div>
      <div className="post-info">
        <div className="post-meta">
          <span><i className="fas fa-calendar-alt"></i> January 24, 2020</span>
          <span><i className="fas fa-comments"></i> 4 Comments</span>
        </div>
        <h3 className="post-title">Insights on How to Improve Your Teaching.</h3>
        <a href="#" className="read-more">Read More <i className="fas fa-arrow-right"></i></a>
      </div>
    </div>
    </div>
    <div class="col-sm-4">
    <div className="category-container">
      <div className="search-bar">
        <input type="text" placeholder="Search..." />
        <i className="fas fa-search"></i>
      </div>
      <div className="categories">
        <h3>Categories</h3>
        <ul>
          {categories.map((category) => (
            <li key={category.name}>
              {category.name} <span>({category.count})</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
    </div>
  </div>
</div>
<br/><br/><br/>
<div class="container">
  <div class="row">
    <div class="col">
    <div className="post-card">
      <div className="post-image">
        <img src="https://img.freepik.com/premium-psd/discount-3d-podium-product-display-social-media-instagram-story-template-flash-sale-super-sale_125322-160.jpg?uid=R134543391&ga=GA1.1.1753247489.1710237827&semt=ais_hybrid" alt="Post" />
      </div>
      <div className="post-info">
        <div className="post-meta">
          <span><i className="fas fa-calendar-alt"></i> January 24, 2020</span>
          <span><i className="fas fa-comments"></i> 4 Comments</span>
        </div>
        <h3 className="post-title">Insights on How to Improve Your Teaching.</h3>
        <a href="#" className="read-more">Read More <i className="fas fa-arrow-right"></i></a>
      </div>
    </div>
    </div>
    <div class="col">
    <div className="post-card">
      <div className="post-image">
        <img src="https://img.freepik.com/premium-psd/discount-3d-podium-product-display-social-media-instagram-story-template-flash-sale-super-sale_125322-160.jpg?uid=R134543391&ga=GA1.1.1753247489.1710237827&semt=ais_hybrid" alt="Post" />
      </div>
      <div className="post-info">
        <div className="post-meta">
          <span><i className="fas fa-calendar-alt"></i> January 24, 2020</span>
          <span><i className="fas fa-comments"></i> 4 Comments</span>
        </div>
        <h3 className="post-title">Insights on How to Improve Your Teaching.</h3>
        <a href="#" className="read-more">Read More <i className="fas fa-arrow-right"></i></a>
      </div>
    </div>
    </div>
    <div class="col">
    <div class="popular-posts">
    <h3>Popular Posts</h3>
    <ul>
        <li>
            <img src="https://img.freepik.com/free-photo/thinking-young-student-boy-sitting-desk-with-school-tools-holding-book-his-thumb-up-yellow_141793-74786.jpg?ga=GA1.1.1753247489.1710237827&semt=ais_hybrid" alt="Post Image"/>
            <div class="post-info">
                <h4>Using creative problem Solving</h4>
                <p>March 18, 2020</p>
            </div>
        </li>
        <li>
            <img src="https://img.freepik.com/free-photo/thinking-young-student-boy-sitting-desk-with-school-tools-holding-book-his-thumb-up-yellow_141793-74786.jpg?ga=GA1.1.1753247489.1710237827&semt=ais_hybrid" alt="Post Image"/>
            <div class="post-info">
                <h4>Fundamentals of UI Design</h4>
                <p>Jan 14, 2020</p>
            </div>
        </li>
        <li>
            <img src="https://img.freepik.com/free-photo/thinking-young-student-boy-sitting-desk-with-school-tools-holding-book-his-thumb-up-yellow_141793-74786.jpg?ga=GA1.1.1753247489.1710237827&semt=ais_hybrid" alt="Post Image"/>
            <div class="post-info">
                <h4>Making music with Other people</h4>
                <p>April 17, 2020</p>
            </div>
        </li>
        <li>
            <img src="https://img.freepik.com/free-photo/thinking-young-student-boy-sitting-desk-with-school-tools-holding-book-his-thumb-up-yellow_141793-74786.jpg?ga=GA1.1.1753247489.1710237827&semt=ais_hybrid" alt="Post Image"/>
            <div class="post-info">
                <h4>Brush strokes energize Trees in paintings</h4>
                <p>July 4, 2020</p>
            </div>
        </li>
    </ul>
</div>

    </div>
  </div>
</div>
<br/><br/><br/>
<div class="container">
  <div class="row">
    <div class="col">
    <div className="post-card">
      <div className="post-image">
        <img src="https://img.freepik.com/premium-psd/discount-3d-podium-product-display-social-media-instagram-story-template-flash-sale-super-sale_125322-160.jpg?uid=R134543391&ga=GA1.1.1753247489.1710237827&semt=ais_hybrid" alt="Post" />
      </div>
      <div className="post-info">
        <div className="post-meta">
          <span><i className="fas fa-calendar-alt"></i> January 24, 2020</span>
          <span><i className="fas fa-comments"></i> 4 Comments</span>
        </div>
        <h3 className="post-title">Insights on How to Improve Your Teaching.</h3>
        <a href="#" className="read-more">Read More <i className="fas fa-arrow-right"></i></a>
      </div>
    </div>
    </div>
    <div class="col">
    <div className="post-card">
      <div className="post-image">
        <img src="https://img.freepik.com/premium-psd/discount-3d-podium-product-display-social-media-instagram-story-template-flash-sale-super-sale_125322-160.jpg?uid=R134543391&ga=GA1.1.1753247489.1710237827&semt=ais_hybrid" alt="Post" />
      </div>
      <div className="post-info">
        <div className="post-meta">
          <span><i className="fas fa-calendar-alt"></i> January 24, 2020</span>
          <span><i className="fas fa-comments"></i> 4 Comments</span>
        </div>
        <h3 className="post-title">Insights on How to Improve Your Teaching.</h3>
        <a href="#" className="read-more">Read More <i className="fas fa-arrow-right"></i></a>
      </div>
    </div>
    </div>
    <div class="col">
    <div class="popular-tags">
    <h3>Popular Tags</h3>
    <div class="tags">
        <span>Blog IMS</span>
        <span>Design</span>
        <span>General</span>
        <span>Online</span>
        <span>Innovation</span>
        <span>Artist</span>
        <span>Education</span>
        <span>Motivation</span>
        <span>Politics</span>
        <span>Live Cases</span>
    </div>
</div>

    </div>
  </div>
</div>
  </div>

 
  )
}
