
import './App.css';
import BlogCard from './components/pages/BlogCard';
// import signup from '..src/..compo/SignUp';

// import './App.css';
// import SignUp from './components/signup';
// import LoginForm from './components/pages/LoginForm';


function App() {
  return (
    <>
    {/* <SignUp/> */}
    {/* <LoginForm/> */}
    <BlogCard></BlogCard>
   

    </>
  );
}

export default App;
